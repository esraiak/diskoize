diskoize:memoize::disk:memory
